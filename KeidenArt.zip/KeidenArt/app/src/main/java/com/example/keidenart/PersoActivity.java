package com.example.keidenart;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

import android.content.SharedPreferences;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Arrays;

public class PersoActivity extends AppCompatActivity {

    private EditText noteEditText;
    private Button saveButton;
    private ListView noteListView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> noteList;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perso);

        // Récupérer les références des vues
        noteEditText = findViewById(R.id.noteEditText);
        saveButton = findViewById(R.id.saveButton);
        noteListView = findViewById(R.id.noteListView);

        // Initialiser la liste des notes et l'adaptateur pour la ListView
        noteList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, noteList);
        noteListView.setAdapter(adapter);

        // Récupérer les préférences partagées pour la sauvegarde des notes
        sharedPreferences = getSharedPreferences("MyNotes", MODE_PRIVATE);
        loadNotesFromSharedPreferences(); // Charger les notes sauvegardées depuis les préférences partagées

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String note = noteEditText.getText().toString();
                noteList.add(note);
                adapter.notifyDataSetChanged();
                noteEditText.setText("");

                saveNotesToSharedPreferences(); // Sauvegarder les notes dans les préférences partagées
            }
        });

        noteListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                removeNoteFromList(position); // Supprimer la note sélectionnée de la liste
            }
        });
    }

    // Charger les notes sauvegardées depuis les préférences partagées
    private void loadNotesFromSharedPreferences() {
        String notesJson = sharedPreferences.getString("notes", "");
        if (!notesJson.isEmpty()) {
            noteList.addAll(Arrays.asList(new Gson().fromJson(notesJson, String[].class)));
            adapter.notifyDataSetChanged();
        }
    }

    // Sauvegarder les notes dans les préférences partagées
    private void saveNotesToSharedPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String notesJson = new Gson().toJson(noteList.toArray(new String[0]));
        editor.putString("notes", notesJson);
        editor.apply();
    }

    // Supprimer la note sélectionnée de la liste
    private void removeNoteFromList(int position) {
        noteList.remove(position);
        adapter.notifyDataSetChanged();
        saveNotesToSharedPreferences(); // Sauvegarder les notes mises à jour dans les préférences partagées
    }
}
